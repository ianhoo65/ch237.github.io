import java.awt.*;
import java.util.List;



public class Missile {
	public static final int XSPEED=10,YSPEED=10,WIDTH=10,HEIGHT=10;
	
	int x,y;
	Tank.Direction dir;
	private boolean live=true;
	private TankClient tc;
	public boolean good;
	private static Toolkit tk=Toolkit.getDefaultToolkit();
	private static Image[] imgs={
		tk.getImage(Missile.class.getClassLoader().getResource("images/1.gif"))
		//tk.getImage(Missile.class.getClassLoader().getResource("images/mymissile.gif"))
	};
	
	public boolean isLive() {
		return live;
	}
	public Missile(int x, int y, Tank.Direction dir) {
		this.x = x;
		this.y = y;
		this.dir = dir;
	}
	public Missile(int x, int y, Tank.Direction dir, boolean good, TankClient tc){
		this(x,y,dir);
		this.good=good;
		this.tc=tc;
	}
	public Rectangle getRect(){
		return new Rectangle(x,y,imgs[0].getWidth(null),imgs[0].getHeight(null));
	}
	public boolean hitTank(Tank t){
		if(this.getRect().intersects(t.getRect()) && t.isLive() && this.live && this.good!=t.isGood()){
			this.live=false;
			t.hitN--;
			if (t.hitN==0){
				t.setLive(false);
			}
			Explode e=new Explode(x,y,tc);
			tc.explodes.add(e);
			return true;			
		}
		return false;
	}
	public boolean hitTank(List<Tank> tanks){
		for(int i=0;i<tanks.size();i++){
			if(hitTank(tanks.get(i))){
				return true;
			}
		}
		return false;
	}
	public void draw(Graphics g){
		Color c=g.getColor();
		if(good){
			g.setColor(Color.PINK);
			//g.setColor(Color.CYAN);
			g.fillOval(x, y, 8, 8);	
			g.setColor(Color.MAGENTA);
			g.fillOval(x+2, y+2, 4, 4);
			//g.drawImage(imgs[1], x,y,null);
		}
		else{
			g.drawImage(imgs[0], x,y,null);
			//g.drawImage(imgs[0], x,y,null);
		}
		//g.fillOval(x, y, 10, 10);
		g.setColor(c);
		move();
	}
	private void move() {
		// TODO Auto-generated method stub
		
		switch(dir){
		case L:
			x-=XSPEED;
			break;
		case LU:
			x-=XSPEED;
			y-=YSPEED;
			break;
		case LD:
			x-=XSPEED;
			y+=YSPEED;
			break;
		case RU:
			x+=XSPEED;
			y-=YSPEED;
			break;
		case RD:
			x+=XSPEED;
			y+=YSPEED;
			break;
		case U:
			y-=YSPEED;
			break;
		case R:
			x+=XSPEED;
			break;
		case D:
			y+=YSPEED;;
			break;
		}
		if (x<0 || y<0 || x>TankClient.GAMEWIDTH || y>TankClient.GAMELENGTH){
			live=false;			
		}
		if (!live) tc.missiles.remove(this);
	}
	

}
