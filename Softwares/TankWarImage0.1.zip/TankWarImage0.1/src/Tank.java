import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class Tank {
	public static final int XSPEED=5, YSPEED=5,WIDTH=40,HEIGHT=40;
	
	TankClient tc=null;
	int hitN;
	
	private boolean bL=false,bU=false,bR=false,bD=false;
	enum Direction{L,U,D,R,LU,LD,RU,RD,STOP};
	private Direction dir=Direction.STOP;
	private Direction fireDir=Direction.U;
	private boolean good;
	private static Toolkit tk=Toolkit.getDefaultToolkit();
	private static Image[] tankImages=null;
	private static Map<String,Image> imgs=new HashMap<String,Image>();
	static{
		tankImages=new Image[]{
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankL.gif")),
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankLU.gif")),
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankU.gif")),
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankRU.gif")),
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankR.gif")),
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankRD.gif")),
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankD.gif")),
				tk.getImage(Tank.class.getClassLoader().getResource("images/tankLD.gif"))	
		};
		imgs.put("L", tankImages[0]);
		imgs.put("LU", tankImages[1]);
		imgs.put("U", tankImages[2]);
		imgs.put("RU", tankImages[3]);
		imgs.put("R", tankImages[4]);
		imgs.put("RD", tankImages[5]);
		imgs.put("D", tankImages[6]);
		imgs.put("LD", tankImages[7]);
	}

	public boolean isGood() {
		return good;
	}
	private boolean live=true;
	private Random r=new Random();
	
	public boolean isLive() {
		return live;
	}
	public void setLive(boolean live) {
		this.live = live;
	}
	private int x,y;//location of tank
	public Tank(int x, int y, boolean good) {
		this.x = x;
		this.y = y;
		this.good=good;
	}
	public Tank(int x,int y,boolean good, Direction dir, TankClient tc){
		this(x,y,good);//call the first constructor to assign values to x and y
		this.dir=dir;
		this.tc=tc;
		if(good){
			hitN=10;
		}
		else{
			hitN=3;
		}
	}
	public void draw(Graphics g){
		if(!live){
			if (!this.good){
				tc.tanks.remove(this);
			}
			return;
		}
		/*Color c=g.getColor();//reserve the foreground color, the default color is black
		if(good) g.setColor(Color.red);
		else g.setColor(Color.lightGray);
		g.fillOval(x, y, WIDTH, HEIGHT);
		g.setColor(c);//set the foreground color to the default color
		*/
		if(good){
			Color c=g.getColor();
			g.setColor(Color.RED);
			g.drawRect(x, y-10,50, 5);
			g.fillRect(x, y-10, 0+5*hitN, 5);
			g.setColor(c);
		}
		switch(fireDir){
		case L:
			//g.drawLine(x+WIDTH/2, y+HEIGHT/2, x, y+HEIGHT/2);
			g.drawImage(imgs.get("L"), x,y,null);
			break;
		case LU:
			//g.drawLine(x+WIDTH/2, y+HEIGHT/2, x, y);
			g.drawImage(imgs.get("LU"), x,y,null);
			break;
		case LD:
			g.drawImage(imgs.get("LD"), x,y,null);
			break;
		case RU:
			g.drawImage(imgs.get("RU"), x,y,null);
			break;
		case RD:
			g.drawImage(imgs.get("RD"), x,y,null);
			break;
		case U:
			g.drawImage(imgs.get("U"), x,y,null);
			break;
		case R:
			g.drawImage(imgs.get("R"), x,y,null);
			break;
		case D:
			g.drawImage(imgs.get("D"), x,y,null);
			break;
		}
		move();
	}
	void move(){
		switch(dir){
		case L:
			x-=XSPEED;
			break;
		case LU:
			x-=XSPEED;
			y-=YSPEED;
			break;
		case LD:
			x-=XSPEED;
			y+=YSPEED;
			break;
		case RU:
			x+=XSPEED;
			y-=YSPEED;
			break;
		case RD:
			x+=XSPEED;
			y+=YSPEED;
			break;
		case U:
			y-=YSPEED;
			break;
		case R:
			x+=XSPEED;
			break;
		case D:
			y+=YSPEED;;
			break;
		case STOP:
			break;
		}
		if(this.dir!=Direction.STOP){
			this.fireDir=this.dir;
		}
		if(x<0) x=0;
		if(y<30) y=30;
		if(x>TankClient.GAMEWIDTH-tankImages[0].getWidth(null)) x=TankClient.GAMEWIDTH-tankImages[0].getWidth(null);
		if(y>TankClient.GAMELENGTH-tankImages[0].getHeight(null)) y=TankClient.GAMELENGTH-tankImages[0].getHeight(null);
		if(!good){
			Direction[] dirs=Direction.values();
			int rn=r.nextInt(dirs.length);
			if(rn%dirs.length==0||x<0 || y<30 || x>TankClient.GAMEWIDTH-tankImages[0].getWidth(null) || y>TankClient.GAMELENGTH-tankImages[0].getHeight(null)){
				dir=dirs[r.nextInt(dirs.length)];				
			}
			if(r.nextInt(100)>90){
				this.fire();
			}
			
		}
	}
	public void keyPressed(KeyEvent e) {
		int key=e.getKeyCode();
		switch(key){
		case KeyEvent.VK_LEFT:
			bL=true;
			break;
		case KeyEvent.VK_UP:
			bU=true;
			break;
		case KeyEvent.VK_RIGHT:
			bR=true;
			break;
		case KeyEvent.VK_DOWN:
			bD=true;
			break;
		}
		locateDirection();
	}
	void locateDirection(){
		if(bL && !bU && !bR && !bD) dir = Direction.L;
		else if(bL && bU && !bR && !bD) dir = Direction.LU;
		else if(!bL && bU && !bR && !bD) dir = Direction.U;
		else if(!bL && bU && bR && !bD) dir = Direction.RU;
		else if(!bL && !bU && bR && !bD) dir = Direction.R;
		else if(!bL && !bU && bR && bD) dir = Direction.RD;
		else if(!bL && !bU && !bR && bD) dir = Direction.D;
		else if(bL && !bU && !bR && bD) dir = Direction.LD;
		else if(!bL && !bU && !bR && !bD) dir = Direction.STOP;
	}
	public void keyReleased(KeyEvent e) {
		int key=e.getKeyCode();
		switch(key){
		case KeyEvent.VK_CONTROL:
			fire();
			break;
		case KeyEvent.VK_LEFT:
			bL=false;
			break;
		case KeyEvent.VK_UP:
			bU=false;
			break;
		case KeyEvent.VK_RIGHT:
			bR=false;
			break;
		case KeyEvent.VK_DOWN:
			bD=false;
			break;
		}
		locateDirection();		
	}
	
	public Missile fire(){
		if(!live){
			return null;
		}
		int x=this.x+tankImages[0].getWidth(null)/2-Missile.WIDTH/2;
		int y=this.y+tankImages[0].getHeight(null)/2-Missile.HEIGHT/2;
		//int x=this.x+Tank.WIDTH/2-Missile.WIDTH/2;
		//int y=this.y+Tank.HEIGHT/2-Missile.HEIGHT/2;
		Missile m=new Missile(x,y,fireDir,this.good,this.tc);
		tc.missiles.add(m);
		return m;
	}
	public Rectangle getRect(){
		return new Rectangle(x-5,y-5,tankImages[0].getWidth(null)-5,tankImages[0].getHeight(null)-5);
	}
}
