import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;


//import Tank.Direction;

public class TankClient extends Frame{
	public static final int GAMEWIDTH=800;
	public static final int GAMELENGTH=600;
	
	//int x=50,y=50;//location, to make the tank move
	
	//use double buffer to solve the screen flashing, repaint-update-paint, rewrite update to
	//paint everything in an image in the buffer, and the copy the image to the screen. 
	Tank myTank=new Tank(50,50,true,Tank.Direction.STOP,this);
	//Tank enemyTank=new Tank(200,200,false, this);
	//Explode e=new Explode(400,400,this);
	//Missile myMissile=new Missile(50,50,Tank.Direction.R);
	//Missile myMissile=null;
	List<Missile> missiles=new ArrayList<Missile>();
	List<Explode> explodes=new ArrayList<Explode>();
	List<Tank> tanks=new ArrayList<Tank>();
	
	Image offScreenImage=null;
	//rewrite paint fun to draw tank
	
	@Override
	public void update(Graphics g) {
		if(offScreenImage==null){
			offScreenImage=this.createImage(GAMEWIDTH,GAMELENGTH);
		}
		//get graphics for offscreen image to paint on it
		Graphics goffScreenImage=offScreenImage.getGraphics();
		Color c=goffScreenImage.getColor();
		goffScreenImage.setColor(Color.BLUE);
		goffScreenImage.fillRect(0, 0, GAMEWIDTH,GAMELENGTH);
		goffScreenImage.setColor(c);
		paint(goffScreenImage);//paint image to offscreen image		
		g.drawImage(offScreenImage, 0, 0, null);
		
	}
	
	public void paint(Graphics g){
		//e.draw(g);
		myTank.draw(g);
		for(int i=0;i<tanks.size();i++){
			Tank t=tanks.get(i);
			t.draw(g);
		}
		//enemyTank.draw(g);
		for(int i=0;i<missiles.size();i++){
			Missile m=missiles.get(i);
			//m.hitTank(enemyTank);
			m.hitTank(tanks);
			m.hitTank(myTank);
			m.draw(g);
		}
		for(int i=0;i<explodes.size();i++){
			Explode e=explodes.get(i);
			e.draw(g);
		}
		g.drawString("missile #: "+missiles.size(), 10, 50);
		g.drawString("explode #: "+explodes.size(),10, 60);
		g.drawString("tank #:  "+tanks.size(),10, 70);
		//if (myMissile!=null) myMissile.draw(g);
		
	}
	public void laughFrame(){
		for(int i=0;i<10;i++){
			tanks.add(new Tank(50+i*60, 400,false, Tank.Direction.D,this));
		}
		this.setLocation(100,100);
		this.setSize(GAMEWIDTH,GAMELENGTH);
		//close the window
		this.addWindowListener(new WindowAdapter(){//rewrite the anonymous class

			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
			
		});
		this.setResizable(false);
		this.setTitle("Tank War!               Developed by Changwei Hu");
		this.setBackground(Color.green);//set the background color to be green
		
		this.addKeyListener(new KeyMonitor());//monitor keyboard event
		
		this.setVisible(true);
		new Thread(new PaintThread()).start();
	}
	private class PaintThread implements Runnable{

		@Override
		public void run() {
			while(true){
				repaint();
				try {
					Thread.sleep(60);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}//repaint and then sleep 200nm
			}						
		}
		
	}
	private class KeyMonitor extends KeyAdapter{

		@Override
		public void keyReleased(KeyEvent e) {
			myTank.keyReleased(e);
		}

		@Override
		public void keyPressed(KeyEvent e) {
			myTank.keyPressed(e);
		}
		
	}
	public static void main(String[] args){
		TankClient tc=new TankClient();
		tc.laughFrame();
	}

}
