function C=Cgenerate(WS,DS)
K=max(DS(:));%document #
J=max(WS(:));
C=zeros(J,K);
for k=1:K
    doc_index=find(DS==k);
    term_index=WS(doc_index);
    for j=1:J
        term_num=sum(term_index==j);
        C(j,k)=term_num;
    end
end