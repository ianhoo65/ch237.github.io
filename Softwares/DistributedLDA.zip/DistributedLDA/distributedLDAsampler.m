clear all;close all;clc;
load 'bagofwords_psychreview';%load the psych review data in Mark Steyvers's toolbox for topic modeling 
load 'words_psychreview';
w=WS';
d=DS';
word=WO;
N=length(w);
D=max(d);
W=length(word);
C=Cgenerate(WS,DS);
save C C;
% load C;

dataset='n'
T=50
P=10
seed=1
ITER  = 5000;
alpha = 1;
beta=0.01;
rand('state',sum(100*clock))


z  = floor(T*rand(N,1)) + 1;
wp = zeros(W,T);
dp = zeros(D,T);
for n = 1:N
  wp(w(n),z(n)) = wp(w(n),z(n)) + 1;
  dp(d(n),z(n)) = dp(d(n),z(n)) + 1;
end
perp=getPerplexity(wp,dp,length(w),C)
ztot = sum(wp,1);
ztotchk = sum(dp,1);

Dp = floor(D/P);
Nstart = 1;

for p=1:P
  
  Dstart = (p-1)*Dp + 1;
  if p<P
    Dend   =     p*Dp;
  else
      Dend=D;
  end
  
  Nend   = full(sum(sum(dp(1:Dend,:))));
  
  data(p).w  =  w( Nstart:Nend );
  data(p).d  =  d( Nstart:Nend ) - (Dstart - 1); % local numbering
  data(p).z  =  z( Nstart:Nend );
  data(p).dp = dp( Dstart:Dend, : );
  
  Nstart = Nend + 1;
  
end

% iterate through distributed sampling
wp_temp=0;
dp_temp=0;
perpall=[];
timeall=[];
tic;
for iter = 1:ITER
    
  fprintf('iter %d\n', iter);

  wp0 = wp;
  ztot0 = sum(wp0);
  dwp = 0*wp;

  for p=1:P
      [wp,data(p).dp,data(p).z]=LDA(data(p).w,data(p).d,T,beta,alpha,data(p).z,ztot0,data(p).dp,wp0);
    dwp = dwp + (wp - wp0);
  end
  wp = wp0 + dwp;
  
  dp=[];
  for p=1:P
      dp=[dp;data(p).dp];
  end
  wp_temp=wp_temp+wp;
  dp_temp=dp_temp+dp;
  
  perp=getPerplexity(wp_temp/iter,dp/iter,length(w),C)
  perpall=[perpall,perp];
  runtime=toc;
  timeall=[timeall,runtime];

end

save PsyRevDistLDA10core

