function perp=getPerplexity(WordCount,TopicCount,N,C)
% K: # of topics
% T: # of terms
% WordCount:count the times each word is assigned to a topic
% N: # of words in corpus
[T,K]=size(WordCount);
M=size(TopicCount,1);
TP_sum=sum(TopicCount,2);
TP=zeros(M,K);
WP_sum=sum(WordCount);
WP=zeros(T,K);
for k=1:K
    WP(:,k)=(WordCount(:,k))/(WP_sum(k)+eps);
end
for m=1:M
    TP(m,:)=(TopicCount(m,:))/(TP_sum(m)+eps);
end
WPTPt=(WP*TP');
logperp=sum(sum(log(WPTPt+eps).*C));
perp=exp(-logperp/N);