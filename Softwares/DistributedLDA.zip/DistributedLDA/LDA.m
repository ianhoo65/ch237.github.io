function [WordCount, TopicCount, Topic]=LDA(WS,DS,T,Beta,Alpha,z,TopicTotCount,dp,wp)
%% Initialization: randomly assign words to topics
% C=Cgenerate(WS,DS);%generate count matrix
WordNum=numel(WS);

RanOrder=randperm(WordNum);%randomrize the order
% RanOrder=1:WordNum;
ProbT=zeros(T,1);%probability for topic


for w=1:WordNum
        RanIndex=RanOrder(w);
        WordIndex=WS(RanIndex);%current word index
        TopicIndex=z(RanIndex);%current topic index
        DocIndex=DS(RanIndex);%current document index
        wp(WordIndex,TopicIndex)=wp(WordIndex,TopicIndex)-1;
        dp(DocIndex,TopicIndex)=dp(DocIndex,TopicIndex)-1;
        TopicTotCount(TopicIndex)=TopicTotCount(TopicIndex)-1;

%% sample topic index
        TotProbT=0;%total probability for topic
        CProbT=zeros(T,1);%cumulative probability for topic
        for t=1:T
            ProbT(t)=(wp(WordIndex,t)+Beta)/(TopicTotCount(t)+WordNum*Beta)*(dp(DocIndex,t)+Alpha);
            TotProbT=TotProbT+ProbT(t);
            CProbT(t)=TotProbT;
        end
        
        RanProb=TotProbT*rand;
        TopicIndex=1;
        for t=1:T
            if RanProb > CProbT(t)
                TopicIndex=TopicIndex+1;
            else
                break;
            end
        end
        z(RanIndex)=TopicIndex;
        wp(WordIndex,TopicIndex)=wp(WordIndex,TopicIndex)+1;
        dp(DocIndex,TopicIndex)=dp(DocIndex,TopicIndex)+1;
        TopicTotCount(TopicIndex)=TopicTotCount(TopicIndex)+1;
        
    end
TopicCount=dp;
Topic=z;
WordCount=wp;
