clear all;close all;clc
%%
load 'bagofwords_psychreview';%load the psych review data in Mark Steyvers's toolbox for topic modeling 
load 'words_psychreview'; 
%%
T=50;%number of topics
Beta=0.01;%dirichlet parameter for word distribution given topic
Alpha=1;%dirichlet parameter for topic distribution given document
IterN=300;%iteration times

[WP DP Z]=LDA(WS,DS,T,Beta,Alpha,IterN);

% load proj_1.mat
BETA=0.01;
W_outputN=7;% # of terms to be displayed in each topic
Topics = OutputTopics( WP , BETA , WO , 7 );

fprintf( '\n\nMost likely words in the first ten topics:\n' );

% Show the most likely words in the first ten topics
Topics(1:10)  
