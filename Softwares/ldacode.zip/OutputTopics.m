function [Topics]=OutputTopics(WP,Beta,WO,W_outputN)
%W_outputN: output terms for each topic
WP_sum=sum(WP);%total number of terms assigned to each topic
[T,Z]=size(WP);%T: # of terms;Z: # of topics
Topics=cell(Z,1);
for z=1:Z
    [WPsort TermIndex]=sort(WP(:,z),'descend');
    WProbSort=(WPsort(1:W_outputN)+Beta)./(WP_sum(z)+Z*Beta);
    WPcum=0;
    str='';
    for index=1:W_outputN
        WPcum=WPcum+WProbSort(index);
%         WPcum(index)=temp;
       
        if WPcum<1
            str=[str ' ' WO{TermIndex(index)}];
        end
    end
    Topics{z}=str;
end
