function [WordCount, TopicCount, Topic]=LDA(WS,DS,T,Beta,Alpha,IterN)

%% Initialization: randomly assign words to topics
WordNum=numel(WS);
Topic=unidrnd(T,[WordNum 1]);
TermNum=max(WS,[],2);
DocNum=max(DS,[],2);
WordCount=zeros(TermNum,T);%count the times each word is assigned to a topic
TopicCount=zeros(DocNum,T);%count the times each document selects a topic
TopicTotCount=zeros(T,1);%count the times the topic is seleted in the corpus
for w=1:WordNum
    WordIndex=WS(w);
    TopicIndex=Topic(w);
    DocIndex=DS(w);
    WordCount(WordIndex,TopicIndex)=WordCount(WordIndex,TopicIndex)+1;
    TopicCount(DocIndex,TopicIndex)=TopicCount(DocIndex,TopicIndex)+1;
    TopicTotCount(TopicIndex)=TopicTotCount(TopicIndex)+1;
end

%%
RanOrder=randperm(WordNum);%randomrize the order
% RanOrder=1:WordNum;
ProbT=zeros(T,1);%probability for topic
for iter=1:IterN
    iter
    for w=1:WordNum
        RanIndex=RanOrder(w);
        WordIndex=WS(RanIndex);%current word index
        TopicIndex=Topic(RanIndex);%current topic index
        DocIndex=DS(RanIndex);%current document index
        WordCount(WordIndex,TopicIndex)=WordCount(WordIndex,TopicIndex)-1;
        TopicCount(DocIndex,TopicIndex)=TopicCount(DocIndex,TopicIndex)-1;
        TopicTotCount(TopicIndex)=TopicTotCount(TopicIndex)-1;

%% sample topic index
        TotProbT=0;%total probability for topic
        CProbT=zeros(T,1);%cumulative probability for topic
        for t=1:T
            ProbT(t)=(WordCount(WordIndex,t)+Beta)/(TopicTotCount(t)+WordNum*Beta)*(TopicCount(DocIndex,t)+Alpha);
            TotProbT=TotProbT+ProbT(t);
            CProbT(t)=TotProbT;
        end
        
        RanProb=TotProbT*rand;
        TopicIndex=1;
        for t=1:T
            if RanProb > CProbT(t)
                TopicIndex=TopicIndex+1;
            else
                break;
            end
        end
        Topic(RanIndex)=TopicIndex;
        WordCount(WordIndex,TopicIndex)=WordCount(WordIndex,TopicIndex)+1;
        TopicCount(DocIndex,TopicIndex)=TopicCount(DocIndex,TopicIndex)+1;
        TopicTotCount(TopicIndex)=TopicTotCount(TopicIndex)+1;
    end
end